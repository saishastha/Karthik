import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hospital-view-request',
  templateUrl: './hospital-view-request.component.html',
  styleUrls: ['./hospital-view-request.component.css']
})
export class HospitalViewRequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
