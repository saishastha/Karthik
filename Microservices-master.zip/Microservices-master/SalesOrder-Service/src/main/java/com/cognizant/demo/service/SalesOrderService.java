package com.cognizant.demo.service;


import com.cognizant.demo.exception.SalesOrderAlreadyExistsException;

import java.util.List;

import com.cognizant.demo.exception.CustomerAlreadyExistsException;
import com.cognizant.demo.exception.CustomerNotFoundException;
import com.cognizant.demo.model.Customer;
import com.cognizant.demo.model.ItemInfo;
import com.cognizant.demo.model.OrderLineItem;
import com.cognizant.demo.model.SalesOrder;
import com.cognizant.demo.model.SalesOrderDetails;


public interface SalesOrderService {

    	/*
	 * Should not modify this interface. You have to implement these methods in
	 * corresponding Impl classes
	 */
    
    Customer customerValidation(int id) throws CustomerNotFoundException;
    
    int saveSalesOrderDetails(SalesOrder salesOrder)throws SalesOrderAlreadyExistsException;
    
}
