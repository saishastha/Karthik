package com.cognizant.demo.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.demo.exception.SalesOrderAlreadyExistsException;
import com.cognizant.demo.exception.CustomerNotFoundException;
import com.cognizant.demo.exception.ItemNotFoundException;
import com.cognizant.demo.model.Customer;
import com.cognizant.demo.model.ItemInfo;
import com.cognizant.demo.model.OrderLineItem;
import com.cognizant.demo.model.SalesOrder;
import com.cognizant.demo.model.SalesOrderDetails;
import com.cognizant.demo.service.ItemServiceProxy;
import com.cognizant.demo.service.SalesOrderService;

/*
 * As in this assignment, we are working on creating RESTful web service, hence annotate
 * the class with @RestController annotation. A class annotated with the @Controller annotation
 * has handler methods which return a view. However, if we use @ResponseBody annotation along
 * with @Controller annotation, it will return the data directly in a serialized 
 * format. Starting from Spring 4 and above, we can use @RestController annotation which 
 * is equivalent to using @Controller and @ResposeBody annotation
 */

@RefreshScope
@RestController
public class SalesOrderController {

	/*
	 * Autowiring should be implemented for the UserAuthenticationService. (Use
	 * Constructor-based autowiring) Please note that we should not create an object
	 * using the new keyword
	 */
	//@Value("${spring.data.mongodb.host}")
	private String host;
	//@Value("${spring.data.mongodb.port}")
	private String port;
	//@Value("${spring.data.mongodb.database}")
	private String database;
//	@Autowired
//    private  DataSource datasource; 


	@Autowired
	private SalesOrderService salesOrderService;
	@Autowired
	private ItemServiceProxy itemserviceproxy;
	

	@Autowired
	public SalesOrderController(SalesOrderService salesOrderService) {
		this.salesOrderService = salesOrderService;
	}

	/*
	 * Define a handler method which will create a specific user by reading the
	 * Serialized object from request body and save the user details in the
	 * database. This handler method should return any one of the status messages
	 * basis on different situations: 1. 201(CREATED) - If the user created
	 * successfully. 2. 409(CONFLICT) - If the userId conflicts with any existing
	 * user
	 * 
	 * This handler method should map to the URL "/service3/Orders" using HTTP
	 * POST method
	 */

	@PostMapping(value = "/service3/Orders")
	public ResponseEntity<Integer> createOrder(@RequestBody SalesOrderDetails salesOrderDetails) {
		//Customer customer=null;
		int orderId=0;
	
		try {
			if((this.salesOrderService.customerValidation(salesOrderDetails.getCust_id()))!=null) {
				double total_price=0.00;
				List<OrderLineItem> iteminfos=new ArrayList<OrderLineItem>();
				int lineItemId=1;
				if(salesOrderDetails.getIteNames()!=null) {
				
					for (Map.Entry<String, Integer> items : salesOrderDetails.getIteNames().entrySet()) {
						String  itemName = (String ) items.getKey();
						int item_quantity=(int)items.getValue();
						ItemInfo iteminfo=this.itemserviceproxy.findByItemName(itemName);
						total_price+=iteminfo.getPrice();
						OrderLineItem lineitem=new OrderLineItem();
						lineitem.setId(lineItemId);
						lineitem.setItem_Name(itemName);
						lineitem.setItem_quantity(item_quantity);
						lineitem.setOrder_id(salesOrderDetails.getOrder_id());
						iteminfos.add(lineitem);
						lineItemId++;
					}
					SalesOrder salesorder=new SalesOrder();
					salesorder.setId(salesOrderDetails.getOrder_id());
					salesorder.setCust_id(salesOrderDetails.getCust_id());
					salesorder.setOrder_desc(salesOrderDetails.getOrder_desc());
					salesorder.setOrder_date(salesOrderDetails.getOrder_date());
					salesorder.setPrice(total_price);
                    salesorder.setLineItems(iteminfos); 
					
					orderId=this.salesOrderService.saveSalesOrderDetails(salesorder);
//					if(orderId!=0) {
//					for (Iterator iterator = iteminfos.iterator(); iterator.hasNext();) {
//						OrderLineItem orderLineItem = (OrderLineItem) iterator.next();
//						orderLineItem.setOrder_id(orderId);
//						
//					}
//					this.salesOrderService.saveOrderLineItemDetails(iteminfos);
//					}
					
				}else {
					return new ResponseEntity<Integer>(HttpStatus.NOT_FOUND);
				}
			
		}
			
		} catch (SalesOrderAlreadyExistsException e) {
			// TODO Auto-generated catch block
			return new ResponseEntity<Integer>(HttpStatus.CONFLICT);
			// e.printStackTrace();
		}catch(CustomerNotFoundException e) {
			return new ResponseEntity<Integer>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Integer>(orderId, HttpStatus.CREATED);
	}



}
