package com.cognizant.demo.exception;

public class SalesOrderAlreadyExistsException extends Exception {

    public SalesOrderAlreadyExistsException(String message) {
        super(message);
    }
}
