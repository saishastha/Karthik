package com.cognizant.demo.service;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cognizant.demo.model.ItemInfo;



@FeignClient(name="ItemService")
@RibbonClient(name="ItemService")
public interface ItemServiceProxy {
	
	@GetMapping(value = "/service2/items/{itemName}")
	public ItemInfo findByItemName(@PathVariable("itemName") String itemName);
}
