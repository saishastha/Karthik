package com.cognizant.demo.model;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class SalesOrderDetails {
	private int order_id;
	private String order_desc;
	private Date order_date;
	private int cust_id;
	private Map<String,Integer> iteNames;

	public int getOrder_id() {
		return order_id;
	}

	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}

	public String getOrder_desc() {
		return order_desc;
	}

	public void setOrder_desc(String order_desc) {
		this.order_desc = order_desc;
	}

	public Date getOrder_date() {
		return order_date;
	}

	public void setOrder_date(Date order_date) {
		this.order_date = order_date;
	}

	public int getCust_id() {
		return cust_id;
	}

	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}

	public Map<String, Integer> getIteNames() {
		return iteNames;
	}

	public void setIteNames(Map<String, Integer> iteNames) {
		this.iteNames = iteNames;
	}


}
