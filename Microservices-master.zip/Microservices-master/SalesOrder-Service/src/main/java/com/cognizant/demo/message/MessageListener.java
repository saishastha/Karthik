package com.cognizant.demo.message;

import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

import com.cognizant.demo.exception.CustomerAlreadyExistsException;
import com.cognizant.demo.model.Customer;
import com.cognizant.demo.repository.CustomerRepository;

@Service
public class MessageListener {

	/* Constants */
	public static final int MESSAGE_RETRY_DELAY = 5000;
	@Autowired
	private CustomerRepository customerRepository;
	@Autowired
	private MessageConfigReader applicationConfig; 
	public MessageListener(CustomerRepository customerRepository) {
		// TODO Auto-generated constructor stub
		this.customerRepository=customerRepository;
	}
	/**
	 * Message listener for app1
	 * 
	 * @param UserDetails a user defined object used for deserialization of message
	 */
	@RabbitListener(queues = "${app1.queue.name}")
	public void receiveMessageForApp1(final Customer data) {
		try {
			this.saveCustomer(data);
		} catch (HttpClientErrorException ex) {
			if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {

				try {
					Thread.sleep(MESSAGE_RETRY_DELAY);
				} catch (InterruptedException e) {
				}
				// Note: Typically Application specific exception should be thrown below
				throw new RuntimeException();
			} else {
				throw new AmqpRejectAndDontRequeueException(ex);
			}
		} catch (Exception e) {

			throw new AmqpRejectAndDontRequeueException(e);
		}
	}
	
	public Customer saveCustomer(Customer customer) throws CustomerAlreadyExistsException {
		Customer returnObject = (Customer) this.customerRepository.save(customer);
		if (returnObject != null) {
			return returnObject;
		} else {
			throw new CustomerAlreadyExistsException("Customer was already found");
		}
	}

}
