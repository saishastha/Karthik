package com.cognizant.demo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.demo.model.Customer;

@Repository
public interface CustomerRepository  extends MongoRepository<Customer, String>{
	@Query("{ 'id' : ?0 }")
	Customer findCustomer(int   id);
}
