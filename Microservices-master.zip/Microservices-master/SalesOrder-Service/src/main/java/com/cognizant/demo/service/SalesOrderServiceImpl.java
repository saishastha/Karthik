package com.cognizant.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.demo.exception.SalesOrderAlreadyExistsException;
import com.cognizant.demo.exception.CustomerAlreadyExistsException;
import com.cognizant.demo.exception.CustomerNotFoundException;
import com.cognizant.demo.model.Customer;
import com.cognizant.demo.model.ItemInfo;
import com.cognizant.demo.model.OrderLineItem;
import com.cognizant.demo.model.SalesOrder;
import com.cognizant.demo.repository.CustomerRepository;
import com.cognizant.demo.repository.SalesOrderRepository;

/*
* Service classes are used here to implement additional business logic/validation 
* This class has to be annotated with @Service annotation.
* @Service - It is a specialization of the component annotation. It doesn't currently 
* provide any additional behavior over the @Component annotation, but it's a good idea 
* to use @Service over @Component in service-layer classes because it specifies intent 
* better. Additionally, tool support and additional behavior might rely on it in the 
* future.
* */

@Service
public class SalesOrderServiceImpl implements SalesOrderService {

	/*
	 * Autowiring should be implemented for the UserAuthenticationRepository.
	 * (Use Constructor-based autowiring) Please note that we should not create
	 * any object using the new keyword.
	 */
	@Autowired
	private SalesOrderRepository salesOrderRepository;

	@Autowired
	private CustomerRepository customerRepository;
	/*
	 * This method should be used to validate a user using userId and password.
	 * Call the corresponding method of Respository interface.
	 * 
	 */
	@Override
	public Customer customerValidation(int id) throws CustomerNotFoundException {
		 
		Customer customer = (Customer)this.customerRepository.findCustomer(id);
		//System.out.println(userId+"\t"+ password+" after the vcall Check the details"+currentUser.getFirstName()); 
		if (customer != null) {
			return customer;
		} else {
			throw new CustomerNotFoundException("Customers is not found");
		}
	}

	/*
	 * This method should be used to save a new user.Call the corresponding
	 * method of Respository interface.
	 */


	@Override
	public int saveSalesOrderDetails(SalesOrder salesOrder) throws SalesOrderAlreadyExistsException {
		SalesOrder returnObject = (SalesOrder) this.salesOrderRepository.save(salesOrder);
		if (returnObject != null) {
			return returnObject.getId();
		} else {
			throw new SalesOrderAlreadyExistsException("Sales order was already found");
		}
	}
	
}

