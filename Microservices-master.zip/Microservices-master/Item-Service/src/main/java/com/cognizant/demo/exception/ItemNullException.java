package com.cognizant.demo.exception;

public class ItemNullException extends Exception {

    public ItemNullException(String message) {
        super(message);
    }
}
