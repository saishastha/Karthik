package com.cognizant.demo.service;


import java.util.List;



import com.cognizant.demo.exception.ItemNotFoundException;

import com.cognizant.demo.model.Item;


public interface ItemService {

    	/*
	 * Should not modify this interface. You have to implement these methods in
	 * corresponding Impl classes
	 */

    List<Item> getItems() throws ItemNotFoundException;

    Item findItem(String  itemname) throws ItemNotFoundException;
}
