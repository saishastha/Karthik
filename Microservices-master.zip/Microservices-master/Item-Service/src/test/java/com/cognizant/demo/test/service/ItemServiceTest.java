package com.cognizant.demo.test.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.cognizant.demo.exception.ItemNotFoundException;
import com.cognizant.demo.model.Item;
import com.cognizant.demo.repository.ItemRepository;
import com.cognizant.demo.service.ItemService;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

public class ItemServiceTest {

    @Mock
    private ItemRepository itemRepository;

    private Item item;
    @InjectMocks
    private ItemService itemService;

    Optional<Item> optional;
    private List<Item> Items; 

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
      	item = new Item();
        item.setId(1000);
        item.setName("Pampers");
        item.setDescription("The child care");
        item.setItemAddDate(new Date());
        item.setPrice(100.00);
        Items=new ArrayList<Item>();
        Items.add(item);

        optional = Optional.of(item);
    }

    @Test
    public void testGetCustomers() throws ItemNotFoundException {
        Mockito.when(itemRepository.findAll()).thenReturn(Items);
        List<Item> customObject = itemService.getItems();
        
        Assert.assertEquals("Pampers", customObject.get(0).getName());
    }
    

    @Test
    public void testGetItem() {
    	
        Item object = this.itemRepository.findItem(item.getName());
        Assert.assertEquals(item.getName(), object.getName());
    }
}
