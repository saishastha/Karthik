package com.cognizant.demo.test.repository;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;


import com.cognizant.demo.model.Item;
//import com.cognizant.demo.model.User;

//import com.cognizant.demo.repository.UserAutheticationRepository;
import com.cognizant.demo.repository.ItemRepository;

//import javax.persistence.Query;
import java.util.Date;
import java.util.Optional;


@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)


public class ItemRepositoryTest {

    @Autowired
    private ItemRepository itemRepository;

    private Item item;


    @Before
    public void setUp() throws Exception {
    	item = new Item();
        item.setId(1000);
        item.setName("Pampers");
        item.setDescription("The child care");
        item.setItemAddDate(new Date());
        item.setPrice(100.00);
    }

    @After
    public void tearDown() throws Exception {
    	itemRepository.deleteAll();
    }

    @Test
    public void testGetItem() {
    	
        Item object = this.itemRepository.findItem(item.getName());
        Assert.assertEquals(item.getName(), object.getName());
    }

}
