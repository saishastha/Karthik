package com.cognizant.demo.service;


import java.util.List;

import com.cognizant.demo.exception.CustomerAlreadyExistsException;
import com.cognizant.demo.exception.CustomerNotFoundException;
import com.cognizant.demo.model.Customer;


public interface CustomerService {

    	/*
	 * Should not modify this interface. You have to implement these methods in
	 * corresponding Impl classes
	 */

    List<Customer> getCustomers() throws CustomerNotFoundException;

    Customer saveCustomer(Customer customer) throws CustomerAlreadyExistsException;
}
