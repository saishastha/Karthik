package com.cognizant.demo.controller;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.demo.exception.CustomerAlreadyExistsException;
import com.cognizant.demo.exception.CustomerNotFoundException;
import com.cognizant.demo.message.MessageConfigReader;
import com.cognizant.demo.message.MessageSender;
import com.cognizant.demo.model.Customer;
import com.cognizant.demo.service.CustomerService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

/*
 * As in this assignment, we are working on creating RESTful web service, hence annotate
 * the class with @RestController annotation. A class annotated with the @Controller annotation
 * has handler methods which return a view. However, if we use @ResponseBody annotation along
 * with @Controller annotation, it will return the data directly in a serialized 
 * format. Starting from Spring 4 and above, we can use @RestController annotation which 
 * is equivalent to using @Controller and @ResposeBody annotation
 */

//@FeignClient(name = "UserAuthenticationController")
///@RibbonClient(name = "UserAuthenticationController")
@RefreshScope
@RestController
public class CustomerController {

	/*
	 * Autowiring should be implemented for the UserAuthenticationService. (Use
	 * Constructor-based autowiring) Please note that we should not create an object
	 * using the new keyword
	 */
	//@Value("${spring.data.mongodb.host}")
	private String host;
	//@Value("${spring.data.mongodb.port}")
	private String port;
	//@Value("${spring.data.mongodb.database}")
	private String database;
//	@Autowired
//    private  DataSource datasource; 
	private final RabbitTemplate rabbitTemplate;
	private MessageConfigReader applicationConfig;
	private MessageSender messageSender;

	public MessageConfigReader getApplicationConfig() {
		return applicationConfig;
	}

	@Autowired
	public void setApplicationConfig(MessageConfigReader applicationConfig) {
		this.applicationConfig = applicationConfig;
	}

	public MessageSender getMessageSender() {
		return messageSender;
	}

	@Autowired
	public void setMessageSender(MessageSender messageSender) {
		this.messageSender = messageSender;
	}

	@Autowired
	private CustomerService customerService;

	@Autowired
	public CustomerController(CustomerService customerService, final RabbitTemplate rabbitTemplate) {
		System.out.println(this.database+"<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
		this.customerService = customerService;
		this.rabbitTemplate = rabbitTemplate;
	}

	/*
	 * Define a handler method which will create a specific user by reading the
	 * Serialized object from request body and save the user details in the
	 * database. This handler method should return any one of the status messages
	 * basis on different situations: 1. 201(CREATED) - If the user created
	 * successfully. 2. 409(CONFLICT) - If the userId conflicts with any existing
	 * user
	 * 
	 * This handler method should map to the URL "/api/v1/auth/register" using HTTP
	 * POST method
	 */

	@PostMapping(value = "/service1/customer")
	@HystrixCommand(fallbackMethod="getFallBack")
	public ResponseEntity<Customer> registerCustomer(@RequestBody Customer customer) {
		String exchange = getApplicationConfig().getApp1Exchange();
		String routingKey = getApplicationConfig().getApp1RoutingKey();
		try {
			this.customerService.saveCustomer(customer);
			messageSender.sendMessage(rabbitTemplate, exchange, routingKey, customer);
		} catch (CustomerAlreadyExistsException e) {
			// TODO Auto-generated catch block
			return new ResponseEntity<Customer>(HttpStatus.CONFLICT);
			// e.printStackTrace();
		}
		return new ResponseEntity<Customer>(customer, HttpStatus.CREATED);
	}

	/*
	 * Define a handler method which will authenticate a user by reading the
	 * Serialized user object from request body containing the username and
	 * password. The username and password should be validated before proceeding
	 * ahead with JWT token generation. The user credentials will be validated
	 * against the database entries. The error should be return if validation is not
	 * successful. If credentials are validated successfully, then JWT token will be
	 * generated. The token should be returned back to the caller along with the API
	 * response. This handler method should return any one of the status messages
	 * basis on different situations: 1. 200(OK) - If login is successful 2.
	 * 401(UNAUTHORIZED) - If login is not successful
	 * 
	 * This handler method should map to the URL "/api/v1/auth/login" using HTTP
	 * POST method
	 */
	@GetMapping(value = "/service1/customers")
	public ResponseEntity<List<Customer>> getCustomers() {
		List<Customer> customerAll = null;
		try {
			customerAll = this.customerService.getCustomers();
			if (customerAll != null) {
				try {
					return new ResponseEntity<List<Customer>>(customerAll, HttpStatus.OK);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return new ResponseEntity<List<Customer>>(HttpStatus.UNAUTHORIZED);
				}
			} else {
				return new ResponseEntity<List<Customer>>(HttpStatus.UNAUTHORIZED);
			}
		} catch (CustomerNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ResponseEntity<List<Customer>>(HttpStatus.UNAUTHORIZED);
		}

	}
	public ResponseEntity<String> getFallBack() {
		try {
			return new ResponseEntity<String>("",HttpStatus.UNAUTHORIZED);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ResponseEntity<String>("",HttpStatus.UNAUTHORIZED);
		}

	}

}
