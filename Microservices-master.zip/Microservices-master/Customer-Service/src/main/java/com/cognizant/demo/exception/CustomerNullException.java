package com.cognizant.demo.exception;

public class CustomerNullException extends Exception {

    public CustomerNullException(String message) {
        super(message);
    }
}
