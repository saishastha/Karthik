package com.cognizant.demo.message;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;
@Component
public class MessageSender {
	public void sendMessage(RabbitTemplate rabbitTemplate, String exchange, String routingKey, Object data) {
		System.out.println("Sending message to the queue using routingKey {}. Message= {}"+ routingKey+data);
		rabbitTemplate.convertAndSend(exchange, routingKey, data);
		System.out.println("The message has been sent to the queue.");
		}
}
