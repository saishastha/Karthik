package com.cognizant.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.demo.exception.CustomerAlreadyExistsException;
import com.cognizant.demo.exception.CustomerNotFoundException;
import com.cognizant.demo.model.Customer;
import com.cognizant.demo.repository.CustomerRepository;

/*
* Service classes are used here to implement additional business logic/validation 
* This class has to be annotated with @Service annotation.
* @Service - It is a specialization of the component annotation. It doesn't currently 
* provide any additional behavior over the @Component annotation, but it's a good idea 
* to use @Service over @Component in service-layer classes because it specifies intent 
* better. Additionally, tool support and additional behavior might rely on it in the 
* future.
* */

@Service
public class CustomerServiceImpl implements CustomerService {

	/*
	 * Autowiring should be implemented for the UserAuthenticationRepository.
	 * (Use Constructor-based autowiring) Please note that we should not create
	 * any object using the new keyword.
	 */
	@Autowired
	private CustomerRepository customerRepository;

	/*
	 * This method should be used to validate a user using userId and password.
	 * Call the corresponding method of Respository interface.
	 * 
	 */
	@Override
	public List<Customer> getCustomers() throws CustomerNotFoundException {
		 
		List<Customer> currentUser = this.customerRepository.findAll();
		//System.out.println(userId+"\t"+ password+" after the vcall Check the details"+currentUser.getFirstName()); 
		if (currentUser != null) {
			return currentUser;
		} else {
			throw new CustomerNotFoundException("Customers is not found");
		}
	}

	/*
	 * This method should be used to save a new user.Call the corresponding
	 * method of Respository interface.
	 */

	@Override
	public Customer saveCustomer(Customer customer) throws CustomerAlreadyExistsException {
		Customer returnObject = (Customer) this.customerRepository.save(customer);
		if (returnObject != null) {
			return returnObject;
		} else {
			throw new CustomerAlreadyExistsException("Customer was already found");
		}
	}
}
