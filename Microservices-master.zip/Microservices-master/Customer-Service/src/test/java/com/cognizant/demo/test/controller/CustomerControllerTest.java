package com.cognizant.demo.test.controller;

import com.cognizant.demo.controller.CustomerController;
//import com.cognizant.demo.controller.UserAuthenticationController;
//import com.cognizant.demo.exception.UserAlreadyExistsException;
import com.cognizant.demo.model.Customer;
//import com.cognizant.demo.model.User;
import com.cognizant.demo.service.CustomerService;
//import com.cognizant.demo.service.UserAuthenticationService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RunWith(SpringRunner.class)
@WebMvcTest
public class CustomerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CustomerService customerService;

    private Customer customer;

    @InjectMocks
    private CustomerController customerController;

    private List<Customer> customers; 

    @Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(customerController).build();

        customer = new Customer();
        customer.setFirst_name("Jhon");
        customer.setLast_name("Smith");
        customer.setEmail("123456");
        customer.setCustomerAddedDate(new Date());
        customers=new ArrayList<Customer>();
        customers.add(customer);


    }

    @Test
    public void testRegisterCustomer() throws Exception {

        Mockito.when(customerService.saveCustomer(customer)).thenReturn(customer);
        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/auth/register").contentType(MediaType.APPLICATION_JSON).content(jsonToString(customer)))
                .andExpect(MockMvcResultMatchers.status().isCreated()).andDo(MockMvcResultHandlers.print());

    }


    @Test
    public void testGetCustomers() throws Exception {


        Mockito.when(customerService.saveCustomer(customer)).thenReturn(customer);
        Mockito.when(customerService.getCustomers()).thenReturn(customers);
        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/auth/login").contentType(MediaType.APPLICATION_JSON).content(jsonToString(customer)))
                .andExpect(MockMvcResultMatchers.status().isOk()).andDo(MockMvcResultHandlers.print());
    }

    // Parsing String format data into JSON format
    private static String jsonToString(final Object obj) throws JsonProcessingException {
        String result;
        try {
            final ObjectMapper mapper = new ObjectMapper();
            final String jsonContent = mapper.writeValueAsString(obj);
            result = jsonContent;
        } catch (JsonProcessingException e) {
            result = "Json processing error";
        }
        return result;
    }
}
