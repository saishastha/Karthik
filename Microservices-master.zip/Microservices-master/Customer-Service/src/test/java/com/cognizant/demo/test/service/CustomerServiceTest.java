package com.cognizant.demo.test.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.cognizant.demo.exception.CustomerAlreadyExistsException;
import com.cognizant.demo.exception.CustomerNotFoundException;
import com.cognizant.demo.model.Customer;
import com.cognizant.demo.repository.CustomerRepository;
import com.cognizant.demo.service.CustomerService;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

public class CustomerServiceTest {

    @Mock
    private CustomerRepository customerRepository;

    private Customer customer;
    @InjectMocks
    private CustomerService customerService;

    Optional<Customer> optional;
    private List<Customer> customers; 

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        customer = new Customer();
        customer.setFirst_name("Jhon");
        customer.setLast_name("Smith");
        customer.setEmail("123456");
        customer.setCustomerAddedDate(new Date());
        customer.setCustomerAddedDate(new Date());
        customers=new ArrayList<Customer>();
        customers.add(customer);

        optional = Optional.of(customer);
    }

    @Test
    public void testSaveCustomerSuccess() throws CustomerAlreadyExistsException {

        Mockito.when(customerRepository.save(customer)).thenReturn(customer);
        Customer object = customerService.saveCustomer(customer);
        Assert.assertEquals("Cannot Register Customer",customer.getFirst_name(), object.getFirst_name());

    }


    @Test(expected = CustomerAlreadyExistsException.class)
    public void testSaveCustomerFailure() throws CustomerAlreadyExistsException {
        
        Mockito.when(customerRepository.save(customer)).thenReturn(customer);
        Customer object = customerService.saveCustomer(customer);
        Assert.assertEquals("Cannot Register User", object.getFirst_name(), customer.getFirst_name());

    }

    @Test
    public void testGetCustomers() throws CustomerNotFoundException {
        Mockito.when(customerRepository.findAll()).thenReturn(customers);
        List<Customer> customObject = customerService.getCustomers();
        
        Assert.assertEquals("Jhon123", customObject.get(0).getFirst_name());
    }
}
