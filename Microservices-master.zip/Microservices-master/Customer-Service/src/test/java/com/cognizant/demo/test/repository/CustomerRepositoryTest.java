package com.cognizant.demo.test.repository;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.cognizant.demo.model.Customer;
//import com.cognizant.demo.model.User;
import com.cognizant.demo.repository.CustomerRepository;
//import com.cognizant.demo.repository.UserAutheticationRepository;

import java.util.Date;


@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)


public class CustomerRepositoryTest {

    @Autowired
    private CustomerRepository customerRepository;

    private Customer customer;


    @Before
    public void setUp() throws Exception {
    	customer = new Customer();
        customer.setFirst_name("Jhon");
        customer.setLast_name("Smith");
        customer.setEmail("123456");
        customer.setCustomerAddedDate(new Date());;
    }

    @After
    public void tearDown() throws Exception {
    	customerRepository.deleteAll();
    }

    @Test
    public void testRegisterCustomerSuccess() {
    	customerRepository.save(customer);
        Customer object = customerRepository.findById(customer.getFirst_name()).get();
        Assert.assertEquals(customer.getFirst_name(), object.getFirst_name());
    }

}
