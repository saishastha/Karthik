import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-not-participated-form',
  templateUrl: './not-participated-form.component.html',
  styleUrls: ['./not-participated-form.component.scss']
})
export class NotParticipatedFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
