import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-participated-form',
  templateUrl: './participated-form.component.html',
  styleUrls: ['./participated-form.component.scss']
})
export class ParticipatedFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
