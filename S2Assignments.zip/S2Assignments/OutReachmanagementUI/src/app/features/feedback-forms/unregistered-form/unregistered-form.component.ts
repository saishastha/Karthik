import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unregistered-form',
  templateUrl: './unregistered-form.component.html',
  styleUrls: ['./unregistered-form.component.scss']
})
export class UnregisteredFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
