export const UNREGISTERED_REASON = [{
    "reason": "Did not receive further information about the Event."
}]