export const FEEDBACK_QUESTIONS = [{
    "Question": "Hey there. Please share your feedback for unregistering?",
    "Total Answers": 6,
    "Feedback Type": "unregistered"
},
{
    "Question": "Hey there. You had registered for the event. Please let us know the reason?",
    "Total Answers": 6,
    "Feedback Type": "notparticpated"
},
{
    "Question": "How do you rate the overall event?",
    "Total Answers": 5,
    "Feedback Type": "particpated"
}
    ,
{
    "Question": "What did you like about the volunterring activity?",
    "Total Answers": 0,
    "Feedback Type": "particpated"
},
{
    "Question": "What can be improved in this volunteering activity??",
    "Total Answers": 0,
    "Feedback Type": "particpated"
}
]