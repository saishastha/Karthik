export const USER_CREDENTIALS = [{
    "Email": "admin@cognizant.com",
    "Password": "admin",
    "Role": "Admin"

},
{
    "Email": "poc@cognizant.com",
    "Password": "poc",
    "Role": "Poc"
},
{
    "Email": "pmo@cognizant.com",
    "Password": "pmo",
    "Role": "Pmo"
}]