export const POC_DETAILS = [{
    "EMPLOYEE ID": 1,
    "NAME": "John",
    "CONTACT NUMBER": 90575853434
},
{
    "EMPLOYEE ID": 2,
    "NAME": "Kate",
    "CONTACT NUMBER": 8853645733
}]