export const PMO_Details: any[] = [
    {
        "employeeID": 10000,
        "firstName": "John",
        "lastName": "Smith",
        "emailAddress": "johnsmith@cognizant.com",
        "contactNumber": 8853645733,
        "role": "Admin"
    },
    {
        "employeeID": 100001,
        "firstName": "Kate",
        "lastName": "S",
        "emailAddress": "johnsmith@cognizant.com",
        "contactNumber": 6345234356,
        "role": "PMO"
    },
    {
        "employeeID": 100002,
        "firstName": "Peter",
        "lastName": "Mark",
        "emailAddress": "johnsmith@cognizant.com",
        "contactNumber": 544667856456,
        "role": "POC"
    }
]