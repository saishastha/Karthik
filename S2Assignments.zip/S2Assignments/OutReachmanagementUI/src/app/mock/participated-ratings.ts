export const PARTICIPATED_RATING = [{
    "Ratings": "5",
    "Likes": "nice",
    "DisLikes": "travel"
},
{
    "Ratings": "3",
    "Likes": "swimming",
    "DisLikes": "snacks can be provided"
}];