package com.outreach.management.model;

public enum RoleType {

    ADMIN,USER_CREATE,USER_UPDATE,USER
}
