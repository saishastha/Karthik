package com.outreach.management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeedbackManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeedbackManagementApplication.class, args);
	}

}
