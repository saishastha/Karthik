import MoviesList from './MoviesList'
import MoviesInsert from './MoviesInsert'
import MoviesUpdate from './MoviesUpdate'

export { MoviesList, MoviesInsert, MoviesUpdate }
