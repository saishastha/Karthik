package com.kishan.parkinglot;

public enum VehicleSize{
    Motorcycle, CarSize,
}