export interface ILoginAdmin {
    Name: string;
    HosRegn: string;
    Password: string;
    Role: string;
}

export interface ILogin {
    Name: string;
    MobileNumber: string;
    Password: string;
    Role: string;
}
