# EmergencyHelpline


REST API Service details:
    
        1.AuthenticationService
        2.HospitalManagementService
		3.PatientService
		4.ConfigServerService
		5.ServiceDiscovery
		
BFF  Details:

EmergencyHelplineBFF

UI Details	:	

EmergencyHelplineUI

Technical details:

	Development Tools

	1.Visual source code/atom
	2.STS
	3.Apache-maven-3.6.3
	4.java 8
	5.Spring Boot 2.3.2
	6.Angular 9
	7.Node js 12
	8.Spring Cloud-Hoxton.SR6
	9.Swagger Tool



EMPTY
Docker
Docker compose
ZulGateway
deployment.yml - 
service.yml- auto scaling

Initial commit