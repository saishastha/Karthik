export class StockItemServiceConfig {
  baseUrl: string;
}
