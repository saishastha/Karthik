export interface ProjectModel {
  id: number;
  name: string;
}
