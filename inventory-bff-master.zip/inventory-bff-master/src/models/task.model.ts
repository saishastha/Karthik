export interface TaskModel {
  id: number;
  title: string;
  completed: boolean;
  project_id: number;
}
