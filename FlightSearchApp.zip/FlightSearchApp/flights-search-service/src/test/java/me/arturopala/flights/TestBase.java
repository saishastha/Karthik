package me.arturopala.flights;

import junit.framework.TestCase;
import org.junit.Ignore;

@Ignore
public class TestBase extends TestCase {

}
