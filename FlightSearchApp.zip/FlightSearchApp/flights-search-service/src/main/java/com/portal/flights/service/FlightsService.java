package com.portal.flights.service;

import java.time.LocalDateTime;
import java.util.List;

import com.portal.flights.dto.FlightDto;
import com.portal.flights.model.Airport;

public interface FlightsService {

    List<FlightDto> findFlights(Airport departure, Airport arrival, LocalDateTime departureDateTime, LocalDateTime arrivalDateTime, int maxStops, int transferMinutes, int maxTransferMinutes);
}
