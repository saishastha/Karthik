package com.portal.flights.service;

import java.util.List;

import com.portal.flights.model.Airport;
import com.portal.flights.model.Route;

public interface RouteSearchService {

    List<List<Route>> findRoutesBetween(Airport departure, Airport arrival, int maxStops);
}
