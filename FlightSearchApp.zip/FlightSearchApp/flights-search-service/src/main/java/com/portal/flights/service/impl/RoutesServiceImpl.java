package com.portal.flights.service.impl;

import org.jgrapht.DirectedGraph;
import org.jgrapht.graph.DefaultDirectedGraph;
import org.jgrapht.graph.DefaultEdge;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.portal.flights.Constants;
import com.portal.flights.dto.RouteDto;
import com.portal.flights.integration.RoutesApiClient;
import com.portal.flights.model.Airport;
import com.portal.flights.service.RoutesService;

import java.util.List;

@Component
public class RoutesServiceImpl implements RoutesService {

    @Autowired
    private RoutesApiClient routesApiClient;

    @Override
    @Cacheable(Constants.CACHE_ROUTES)
    public DirectedGraph<Airport, DefaultEdge> getAllAvailableRoutes() {
        DirectedGraph<Airport, DefaultEdge> graph = new DefaultDirectedGraph<>(DefaultEdge.class);
        List<RouteDto> routes = routesApiClient.getRoutes();
        routes.stream().forEach( route -> {
            graph.addVertex(route.getAirportFrom());
            graph.addVertex(route.getAirportTo());
            graph.addEdge(route.getAirportFrom(), route.getAirportTo());
        });
        return graph;
    }
}
