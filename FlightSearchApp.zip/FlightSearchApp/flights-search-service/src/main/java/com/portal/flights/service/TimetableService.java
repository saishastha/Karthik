package com.portal.flights.service;

import java.time.YearMonth;
import java.util.Optional;

import com.portal.flights.dto.SchedulesDto;
import com.portal.flights.model.Airport;
import com.portal.flights.model.Timetable;

public interface TimetableService {

    Optional<Timetable> getFlightsTimetable(Airport departure, Airport arrival, YearMonth yearMonth);
}
