package com.portal.flights.service;

import org.jgrapht.DirectedGraph;
import org.jgrapht.graph.DefaultEdge;

import com.portal.flights.model.Airport;

public interface RoutesService {

    DirectedGraph<Airport, DefaultEdge> getAllAvailableRoutes();

}
