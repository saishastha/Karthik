import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { NotesService } from './services/notes.service';
import { AuthenticationService } from './services/authentication.service';
import { RouterService } from './services/router.service';
import { CanActivateRouteGuard } from './can-activate-route.guard';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatToolbarModule } from '@angular/material/toolbar';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { HttpClientModule } from '@angular/common/http';

const appRoutes: Routes = [
  { path: 'dashboard', component: DashboardComponent, canActivate: [CanActivateRouteGuard] },
  { path: 'login', component: LoginComponent },
  { path: '**', redirectTo: '' }
];
export const routing = RouterModule.forRoot(appRoutes);

@NgModule({
  declarations: [AppComponent, HeaderComponent, DashboardComponent, LoginComponent],
  imports: [BrowserModule, HttpClientModule, routing, BrowserAnimationsModule, FormsModule,
    ReactiveFormsModule, MatExpansionModule, MatFormFieldModule, MatToolbarModule,
    MatInputModule, MatTableModule],
  providers: [CanActivateRouteGuard, NotesService, AuthenticationService, RouterService],
  bootstrap: [AppComponent]
})
export class AppModule { }
