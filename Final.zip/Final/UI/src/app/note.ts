export class Note {
    title: string;
    text: String;

}
