package com.stackroute.keepnote.controller;

/*@FeignClient(name="USERAUTHENTICATION-SERVICE")
@RibbonClient(name = "USERAUTHENTICATION-SERVICE")*/
public interface UserAuthenticationControllerClient {

}
