package com.stackroute.keepnote.aspectj;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/* Annotate this class with @Aspect and @Component */
@Component
@Aspect
public class LoggingAspect {
	/*
	 * Write loggers for each of the methods of Category controller, any particular method
	 * will have all the four aspectJ annotation
	 * (@Before, @After, @AfterReturning, @AfterThrowing).
	 */
private Logger logger = LoggerFactory.getLogger(LoggingAspect.class);
	
	@Before("execution(* com.stackroute.keepnote.controller.*.*(..))")
	public void logBefore(JoinPoint joinPoint) {

		logger.info("Entering {}", joinPoint.getSignature());

	}

	@After("execution(* com.stackroute.keepnote.controller.*.*(..))")
	public void logAfter(JoinPoint joinPoint) {

		logger.info("Exiting {}", joinPoint.getSignature());

	}

	@AfterReturning(pointcut = "execution(* com.stackroute.keepnote.controller.*.*(..))", returning = "result")
	public void logAfterReturning(JoinPoint joinPoint, Object result) {

		logger.info("Exiting {}", joinPoint.getSignature());
		logger.info("Returning value: {}", result);

	}

	@AfterThrowing(pointcut = "execution(* com.stackroute.keepnote.controller.*.*(..))", throwing = "e")
	public void logAfterThrowing(JoinPoint joinPoint, Throwable e) {

		logger.error("An exception has been thrown in {}", joinPoint.getSignature());
		logger.error("Cause: {}", e.getCause());

	}
}

