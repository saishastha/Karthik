import { Component, Input } from '@angular/core';
import { Note } from '../note';
import { OnInit } from '@angular/core/src/metadata/lifecycle_hooks';
import { RouterService } from '../services/router.service';

@Component({
  selector: 'app-note',
  templateUrl: './note.component.html',
  styleUrls: ['./note.component.css']
})
export class NoteComponent implements OnInit {

  @Input()
  note: Note;

  ngOnInit() { 
  }

  constructor(private routerService: RouterService) {
  }

  openEditView() {
    this.routerService.routeToEditNoteView(this.note.noteId);
  }
}
