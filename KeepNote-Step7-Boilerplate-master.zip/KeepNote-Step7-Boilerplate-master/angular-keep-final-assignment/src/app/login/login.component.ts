import { Component } from '@angular/core';
import { FormControl } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { Validators } from '@angular/forms';
import { AuthenticationService } from '.././services/authentication.service';
import { RouterService } from '../services/router.service';
import { LoginForm } from './login';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  constructor(private authService: AuthenticationService, private routerService: RouterService) {
  }
  public submitMessage: string;
  userId = new FormControl('', [Validators.required]);
  userPassword = new FormControl('', [Validators.required]);
  loginSubmit() {

    const loginForm = new LoginForm(this.userId.value, this.userPassword.value);
    this.authService.authenticateUser(loginForm).subscribe(
      data => {
        this.authService.setUserId(loginForm.userId);
        this.authService.setBearerToken(data['token']);
        this.authService.isLoggedOff = false;
        this.routerService.routeToDashboard();
      },
      error => {
        if (error.status === 404) {
          this.submitMessage = error.message;
        } else if (error.status === 403) {
          this.submitMessage = error.error.message;
        } else {
          this.submitMessage = error.message;
        }
      });
  }

  getUsernameErrorMsg() {
    return this.userId.hasError('required') ? 'You must enter a username' : '';
  }

  getPasswordErrorMsg() {
    return this.userPassword.hasError('required') ? 'You must enter a password' : '';
  }


  register(){
    this.routerService.routeToRegister();
  }
}
