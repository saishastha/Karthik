import { FormControl } from '@angular/forms';

export class LoginForm {
    public userId: string;
    public userPassword: string;

    constructor(username, password) {
        this.userId = username;
        this.userPassword = password;
    }
}
