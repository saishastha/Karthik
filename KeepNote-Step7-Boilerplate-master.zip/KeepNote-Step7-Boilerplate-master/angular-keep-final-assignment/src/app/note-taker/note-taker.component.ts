import { Component, OnInit } from '@angular/core';
import { Note } from '../note';
import { NotesService } from '../services/notes.service';
import { AuthenticationService } from '../services/authentication.service';
import { RouterService } from '../services/router.service';
import { CategoryService } from '../services/category.service';
import { Category } from '../category';

@Component({
  selector: 'app-note-taker',
  templateUrl: './note-taker.component.html',
  styleUrls: ['./note-taker.component.css']
})
export class NoteTakerComponent implements OnInit {

  errorMessage: string;

  note: Note = new Note();
  notes: Array<Note> = new Array<Note>();
  categories: Array<Category> = new Array<Category>();

  constructor(private noteService: NotesService, private authService: AuthenticationService, private routerService: RouterService,
  private categoryService: CategoryService) {
  }

  ngOnInit() { 
    this.categoryService.getCategories().subscribe(res=>{
      this.categories = res;
    });

  }

  addNote() {
    if (this.note.noteTitle === '' || this.note.noteContent === '') {
      this.errorMessage = 'Title and Text both are required fields';
    } else {

      this.note.noteCreatedBy = this.authService.getUserId();
      this.notes.push(this.note);
      this.noteService.addNote(this.note).subscribe(
        data => {
          this.note = data;
        },
        err => {
          this.errorMessage = err.message;
          console.log('err.message:' + err.message);
          const noteIndex = this.notes.findIndex(note => note.noteTitle === this.note.noteTitle);
          this.notes.splice(noteIndex, 1);
        });
        

    }
    this.note = new Note();
    window.location.reload();
  }
}
