import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../services/authentication.service';
import { RouterService } from '../services/router.service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  constructor( private authService: AuthenticationService, private routerService: RouterService)
  { }

  ngOnInit() {
    this.authService.isLoggedOff = true;
    this.authService.clearlocalstore();
  }

  routeToLogin() {
    this.routerService.routeToLogin();
  }
}
