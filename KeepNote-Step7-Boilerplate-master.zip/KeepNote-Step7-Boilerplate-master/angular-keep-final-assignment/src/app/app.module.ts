import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { NoteViewComponent } from './note-view/note-view.component';
import { ListViewComponent } from './list-view/list-view.component';
import { LoginComponent } from './login/login.component';
import { EditNoteOpenerComponent } from './edit-note-opener/edit-note-opener.component';
import { RouterModule, Routes } from '@angular/router';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatToolbarModule, MatInputModule, MatSelectModule, MatIconModule, MatFormFieldControl, MatOptionModule } from '@angular/material';
import { MatFormFieldModule, MatCardModule, MatButtonModule, MatDialogModule, MatSidenavModule } from '@angular/material';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterService } from './services/router.service';
import { NotesService } from './services/notes.service';
import { CategoryService } from './services/category.service';
import { AuthenticationService } from './services/authentication.service';
import { CanActivateRouteGuard } from './can-activate-route.guard';
import { HttpClientModule } from '@angular/common/http';
import { EditNoteViewComponent } from './edit-note-view/edit-note-view.component';
import { NoteComponent } from './note/note.component';
import { NoteTakerComponent } from './note-taker/note-taker.component';
import { UserRegisterComponent } from './user-register/user-register.component';
import { CategoryComponent } from './category/category.component';
import { EditCategoryComponent } from './category/edit-category.component';
import { ReminderComponent } from './reminder/reminder.component';
import { AgGridModule } from 'ag-grid-angular';
import { LogoutComponent } from './logout/logout.component';

// routes along with their childs
const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'register', component: UserRegisterComponent },
  { path: 'logout', component: LogoutComponent },
  { path: 'category', component: CategoryComponent, canActivate: [CanActivateRouteGuard]},
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [CanActivateRouteGuard],
    children: [
      {
        path: 'view/noteview',
        component: NoteViewComponent,
        canActivate: [CanActivateRouteGuard]
      },
      {
        path: 'view/listview',
        component: ListViewComponent,
        canActivate: [CanActivateRouteGuard]
      },
      {
        path: '',
        redirectTo: 'view/noteview',
        pathMatch: 'full',
        canActivate: [CanActivateRouteGuard]
      },
      {
        path: 'note/:noteId/edit',
        component: EditNoteOpenerComponent,
        outlet: 'noteEditOutlet',
        canActivate: [CanActivateRouteGuard]
      }
    ]
  },
  { path: '', component: LoginComponent }
];


@NgModule({
  declarations: [AppComponent, HeaderComponent, DashboardComponent, NoteViewComponent, NoteComponent, UserRegisterComponent,
    ListViewComponent, LoginComponent, EditNoteOpenerComponent, EditNoteViewComponent, NoteTakerComponent, UserRegisterComponent, 
    EditCategoryComponent, CategoryComponent, ReminderComponent, LogoutComponent],
  imports: [CommonModule, BrowserModule, BrowserAnimationsModule, MatDialogModule, MatSidenavModule,
    MatOptionModule, MatToolbarModule, HttpClientModule, MatCardModule, MatFormFieldModule,
    ReactiveFormsModule, FormsModule, MatInputModule, MatSelectModule, MatFormFieldModule, RouterModule, MatButtonModule, MatIconModule,
    RouterModule.forRoot(routes),
    AgGridModule.withComponents([NoteComponent,EditCategoryComponent])],
  providers: [NotesService, RouterService, AuthenticationService, CategoryService, CanActivateRouteGuard],
  bootstrap: [AppComponent],
  entryComponents: [EditNoteViewComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class AppModule { }
