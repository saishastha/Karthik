import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { AuthenticationService } from '../services/authentication.service';
import { RouterService } from '../services/router.service';

@Component({
  selector: 'app-user-register',
  templateUrl: './user-register.component.html',
  styleUrls: ['./user-register.component.css']
})
export class UserRegisterComponent implements OnInit {

  user: User;

  submitMessage: string;
  private bearerToken: string;
  constructor(private authService: AuthenticationService, private routeService: RouterService) {
    this.user = new User();
  }



  ngOnInit() {
  }

  register() {
    this.authService.register(this.user).subscribe(
      res => {
        this.submitMessage = res['message'];
        this.user = new User();
      },
      err => {
        console.log(err.error.message);
        this.submitMessage = "Unable to register";
        this.user = new User();
      }
    );
  }

  routeToLogin() {
    this.routeService.routeToLogin();
  }

}
