import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Note } from '../note';
import { NotesService } from '../services/notes.service';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import { RouterService } from '../services/router.service';
import { Category } from '../category';
import { CategoryService } from '../services/category.service';


@Component({
  selector: 'app-edit-note-view',
  templateUrl: './edit-note-view.component.html',
  styleUrls: ['./edit-note-view.component.css']
})
export class EditNoteViewComponent implements OnInit {
  note: Note;
  states: Array<string> = ['not-started', 'started', 'completed'];
  errMessage: string;
  categories: Array<Category> = new Array<Category>();
  category: String;

  constructor(private matDialogRef: MatDialogRef<EditNoteViewComponent>, private notesService: NotesService,
    private routerService: RouterService, private categoryService:CategoryService,
    @Inject(MAT_DIALOG_DATA) private data: any) {
  }

  ngOnInit() {
    this.note = this.notesService.getNoteById(this.data.noteId);
    this.categoryService.getCategories().subscribe(res=>{
      this.categories = res;
    });

  }
  onSave() {
    if (this.note.noteContent === '' || this.note.noteTitle === '') {
      this.errMessage = 'Title and Text both are required fields';
    } else {
      this.notesService.editNote(this.note).subscribe(
        editNote => {
          this.matDialogRef.close();
          this.notesService.getNotes();
        },
        error => {
          this.handleErrorResponse(error);
        }
      );
    }
  }

  onDelete() {
    if (this.note.noteContent === '' || this.note.noteTitle === '') {
      this.errMessage = 'Title and Text both are required fields';
    } else {

      this.notesService.deleteNote(this.note.noteId).subscribe(
        editNote => {
          this.matDialogRef.close();
        },
        error => {
          this.handleErrorResponse(error);
        }
      );
    }
  }
  handleErrorResponse(error: HttpErrorResponse) {
    if (error.status === 404) {
      this.errMessage = error.message;
    } else {
      this.errMessage = 'An error occured:' + error.error.message;
    }
  }

  /*ngOnDestroy() {
    this.routerService.routeBack();
  }*/
}
