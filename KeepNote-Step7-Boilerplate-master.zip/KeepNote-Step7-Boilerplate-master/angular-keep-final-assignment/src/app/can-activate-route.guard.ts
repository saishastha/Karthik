import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { RouterService } from './services/router.service';
import { AuthenticationService } from './services/authentication.service';


@Injectable()
export class CanActivateRouteGuard implements CanActivate {

  private bearerToken: string;
  private isAuthenticated: boolean;

  constructor(private routerService: RouterService, private authService: AuthenticationService) {
    this.bearerToken = authService.getBearerToken();
  }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    if (this.authService.getBearerToken() == null) {
      this.routerService.routeToLogin();
      return false;
    } else if(this.authService.isUserLoggedOff()){
      this.routerService.routeToLogout();
      return false;
    } 
    return true;
  }

}
