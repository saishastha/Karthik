import { Injectable } from '@angular/core';
import { Note } from '../note';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { tap } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from './authentication.service';
import { HttpHeaderResponse } from '@angular/common/http/src/response';

@Injectable()
export class NotesService {

  notes: Array<Note>;
  notesSubject: BehaviorSubject<Array<Note>>;
  private url = 'http://localhost:9300/api/v1/note';
  private bearerToken: String;
  private userId: String;

  constructor(private httpClient: HttpClient, private authService: AuthenticationService) {
    this.notes = [];
    this.notesSubject = new BehaviorSubject(this.notes);
    this.userId = this.authService.getUserId();
    this.bearerToken = this.authService.getBearerToken();
    this.fetchNotesFromServer();
  }

  fetchNotesFromServer() {

    const getNotesUrl = this.url + `/${this.userId}`;

    return this.httpClient.get<Note[]>(getNotesUrl, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.bearerToken}`)
    })
      .subscribe(data => {
        this.notes = data;
        this.notesSubject.next(this.notes);
      }, err => {
        console.log(err.message);
      });
  }

  // get all notes from ther server
  getNotes(): Observable<Array<Note>> {
    const getNotesUrl = this.url + `/${this.authService.getUserId()}`;

    return this.httpClient.get<Array<Note>>(getNotesUrl, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.bearerToken}`)
    }).pipe(tap(allnotes => {
      this.notes = allnotes;
      this.notesSubject.next(this.notes);
    }, err => {
      console.log(err.message);
    }));
  }

  addNote(note: Note) {
    return this.httpClient.post<Note>(this.url, note, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.bearerToken}`)
    }).pipe(tap(addedNote => {
      this.notes.push(addedNote);
      this.notesSubject.next(this.notes);
    }));

  }

  editNote(note: Note): Observable<Note> {
    const noteId = note.noteId;
    const getNotesUrl = this.url + `/${this.userId}/`;
    return this.httpClient.put<Note>(getNotesUrl + noteId, note, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.bearerToken}`)
    }).pipe(tap(editedNote => {
      const noteToEdit = this.notes.find(oldNote => oldNote.noteId === editedNote.noteId);
      Object.assign(noteToEdit, editedNote);
      //const noteIndex = this.notes.findIndex(note => note.noteTitle === editedNote.noteTitle);
      console.log(">>>>"+editedNote.noteTitle);
      //console.log(">>>>"+noteToEdit);
      //this.notes.splice(noteIndex+1, 1);
      //this.notes.push(noteToEdit);
      this.notesSubject.next(this.notes);
    }));
  }

  deleteNote(noteId) : Observable<Note> {
    const getNotesUrl = this.url + `/${this.userId}/`;
    return this.httpClient.delete<Note>(getNotesUrl + noteId,  {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.bearerToken}`)
    }).pipe(tap(res => {
      this.notes= this.notes.filter(eachnote => eachnote.noteId !== noteId);
      this.notesSubject.next(this.notes);
     }));;
  }


  getNoteById(noteId): Note {
    const note = this.notes.find(oldNote => oldNote.noteId === noteId);
    return Object.assign({}, note);
  }
}
