import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/map';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class AuthenticationService {

  private authUrl: string;
  isLoggedOff: boolean;
  public logOffSubject = new BehaviorSubject(this.isLoggedOff);

  constructor(private httpClient: HttpClient) {
    this.authUrl = 'http://localhost:3000/auth/v1/';
  }

  authenticateUser(user) {
    return this.httpClient.post('http://localhost:9100/api/v1/auth/login', user, {
      headers: new HttpHeaders().set('Content-Type', 'application/json')
    });
  }

  setUserId(userId) {
    localStorage.setItem('userId', userId);
    
  }

  getUserId() {
    return localStorage.getItem('userId');
  }

  setBearerToken(token) {
    this.logOffSubject.next(false);
    localStorage.setItem('bearerToken', token);
  }

  getBearerToken() {
    return localStorage.getItem('bearerToken');
  }

  clearlocalstore() {
    //this.isLoggedIn =false;
    localStorage.removeItem('bearerToken');
    localStorage.removeItem('userId');
  }

  register(user) {
    return this.httpClient.post('http://localhost:9100/api/v1/auth/register', user, {
      headers: new HttpHeaders().set('Content-Type', 'application/json')
    });
  }

  isUserLoggedOff(){
    // this.logOffSubject.next(this.isLoggedOff);
    return this.isLoggedOff;
  }


  isUserAuthenticated(token): Promise<boolean> {
    const myHeader = new Headers();
    myHeader.set('Authorization', 'Bearer ' + token);
    return fetch(this.authUrl + 'isAuthenticated', {
      method: 'POST',
      body: {},
      headers: myHeader
    }).then(response => {
      return response.json();
    }).catch(error => {
      return false;
    });
  }
}

