import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Category } from '../category';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from './authentication.service';
import { Observable } from 'rxjs/Observable';
import { tap } from 'rxjs/operators';


@Injectable()
export class CategoryService {

  categories: Array<Category>;
  categorySubject: BehaviorSubject<Array<Category>>;
  private url = 'http://localhost:9400/api/v1/category';
  private bearerToken: String;
  private userId: String;

  constructor(private httpClient: HttpClient, private authService: AuthenticationService) {
    this.categories = [];
    this.categorySubject = new BehaviorSubject(this.categories);
    this.userId = this.authService.getUserId();
    this.bearerToken = this.authService.getBearerToken();
    this.fetchCategoriesFromServer();
  }

  fetchCategoriesFromServer() {
    const getCategoriesUrl = 'http://localhost:9400/api/v1/categories/'+`${this.userId}`;

    return this.httpClient.get<Category[]>(getCategoriesUrl, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.bearerToken}`)
    })
      .subscribe(data => {
        this.categories = data;
        this.categorySubject.next(this.categories);
      }, err => {
        console.log(err.message);
      });
  }

   // get all categoriesCategories from ther server
   getCategories(): Observable<Array<Category>> {
    const getCategoriesUrl = 'http://localhost:9400/api/v1/categories/'+`${this.userId}`;

    return this.httpClient.get<Array<Category>>(getCategoriesUrl, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.bearerToken}`)
    }).pipe(tap(data => {
        this.categories = data;
        this.categorySubject.next(this.categories);
    }, err => {
      this.categories =[];
    }));
  }

  addCategory(category: Category) {
    return this.httpClient.post<Category>(this.url, category, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.bearerToken}`)
    }).pipe(tap(data => {
      this.categories.push(data);
      this.categorySubject.next(this.categories);
    }));

  }
  editCategory(category: Category): Observable<Category> {
    return this.httpClient.put<Category>(`http://localhost:9400/api/v1/category/${category.id}`, category, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.bearerToken}`)
    }).pipe(tap(editedcategory => {
      const newcategory = this.categories.find(eachcategory => eachcategory.id === editedcategory.id);
      Object.assign(newcategory, editedcategory);
      this.categorySubject.next(this.categories);
    }, error => {
      console.log(error.message);
    }));
  }

  deleteCategory(category: Category) : Observable<Category> {
    return this.httpClient.delete<Category>(`http://localhost:9400/api/v1/category/${category.id}`,  {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.bearerToken}`)
    }).pipe(tap(res => {
      this.categories= this.categories.filter(eachcategory => eachcategory.id !== category.id);
      this.categorySubject.next(this.categories);
      window.location.reload();
     }));
  }

  getCategoryById(categoryId): Category {
    const category = this.categories.find(oldCat => oldCat.id === categoryId);
    return Object.assign({}, category);
  }
}
