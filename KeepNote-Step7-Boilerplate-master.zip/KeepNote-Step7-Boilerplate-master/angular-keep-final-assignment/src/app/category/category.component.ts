import { Component, OnInit } from '@angular/core';
import { Category } from '../category';
import { AuthenticationService } from '../services/authentication.service';
import { CategoryService } from '../services/category.service';
import { EditCategoryComponent } from '../category/edit-category.component';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

  category: Category;
  categories: Array<Category>;
  submitMessage: string;
  errMessage: string
  constructor(private categoryService: CategoryService, private authService: AuthenticationService) {
    this.category = new Category();
  }

  columnDefs = [
		{headerName: 'Title', field: 'categoryName', editable: true },
		{headerName: 'Description', field: 'categoryDescription', editable: true },
		{headerName: 'Actions',  field:'id', cellRendererFramework: EditCategoryComponent }
	];
  

  ngOnInit() {
    this.categoryService.getCategories().subscribe(
      res => { this.categories = res },
      err => { this.errMessage = err.message; }
    )
  }

  create() {
    this.category.categoryCreatedBy = this.authService.getUserId();
    if (this.category.id === "") {
      this.categoryService.addCategory(this.category).subscribe(
        res => {
          this.submitMessage = "Success"
          console.log("successfully added");
          this.category = new Category();
        },
        err => {
          console.log(err.message)
          this.errMessage = err.message;
          this.category = new Category();
        }
      );;
      window.location.reload();
    }
  }

}
