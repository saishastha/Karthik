import { Component, Input, OnInit } from '@angular/core';
import { RouterService } from '../services/router.service';
import { ICellRendererAngularComp } from "ag-grid-angular";
import { CategoryService } from '../services/category.service';

@Component({
    selector: 'CategoryComponent',
    template: `
        <button style="height: 21px" (click)="openEditViewClick()" class="btn btn-info">Edit</button>&nbsp;<button style="height: 21px" (click)="deleteCategory()" class="btn btn-info">Delete</button>
    `,
    styles: [
        `.btn {
            line-height: 0.5;
            width: 50%;
        }`
    ]
})

export class EditCategoryComponent implements ICellRendererAngularComp {

  constructor(private categoryService:CategoryService) { 
  
  }

    private params: any;
    public cell: any;
	
    agInit(params: any): void {
        this.params = params;
        this.cell = {row: params.value, col: params.colDef.headerName};
    }

    public openEditViewClick(): void {
	    this.categoryService.editCategory(this.params.data).subscribe(
	      res=> {
	        console.log("Success")
	      },
	      err=> {
	        console.log(err.error.message)
	      }
	    );;
    }
    
    
    deleteCategory() {
	    this.categoryService.deleteCategory(this.params.data).subscribe(
	      res=> { 
          console.log("Success")
	      },
	      err=> {
	        console.log(err.error.message)
	      }
      );
      window.location.reload();
  	}
  	
  	refresh(): boolean {
        return false;
    }
    
}
