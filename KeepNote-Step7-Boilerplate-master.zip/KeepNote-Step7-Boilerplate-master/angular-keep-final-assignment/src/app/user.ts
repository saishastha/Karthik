export class User {
    userId: string;
    userPassword: string;
    firstName: string;
    lastName: string;
    userRole: string;

    constructor() {
        this.userId = '';
        this.userPassword = '';
        this.firstName = '';
        this.lastName = '';
        this.userRole = '';
    }
}
