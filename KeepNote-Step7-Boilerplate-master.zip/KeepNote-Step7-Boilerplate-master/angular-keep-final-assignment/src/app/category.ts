export class Category {
  id: string;
  categoryName: string;
  categoryDescription: string;
  categoryCreatedBy: string;

  constructor() {
    this.id = '';
    this.categoryName = '';
    this.categoryDescription = '';
    this.categoryCreatedBy = '';
  }
}

