package com.stackroute.keepnote.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.keepnote.exception.NoteNotFoundExeption;
import com.stackroute.keepnote.model.Note;
import com.stackroute.keepnote.model.NoteUser;
import com.stackroute.keepnote.repository.NoteRepository;

/*
* Service classes are used here to implement additional business logic/validation 
* This class has to be annotated with @Service annotation.
* @Service - It is a specialization of the component annotation. It doesn't currently 
* provide any additional behavior over the @Component annotation, but it's a good idea 
* to use @Service over @Component in service-layer classes because it specifies intent 
* better. Additionally, tool support and additional behavior might rely on it in the 
* future.
* */
@Service
public class NoteServiceImpl implements NoteService {

	/*
	 * Autowiring should be implemented for the NoteRepository and MongoOperation.
	 * (Use Constructor-based autowiring) Please note that we should not create any
	 * object using the new keyword.
	 */
	private NoteRepository noteRepo;

	@Autowired
	public NoteServiceImpl(NoteRepository noteRepo) {
		this.noteRepo = noteRepo;
	}
	/*
	 * This method should be used to save a new note.
	 */
	public boolean createNote(Note note) {
		
		NoteUser noteUser = null;
		if (noteRepo.findById(note.getNoteCreatedBy()).isPresent()) {
			noteUser = noteRepo.findById(note.getNoteCreatedBy()).get();
		}
		System.out.println("createNote:::"+noteUser);
		if(noteUser == null) {
			noteUser = new NoteUser();
			List<Note> noteList = new ArrayList<>();
			note.setNoteId(1);
			noteList.add(note);
			noteUser.setNotes(noteList);
			noteUser.setUserId(note.getNoteCreatedBy());
		} else {
			List<Note> noteList = noteUser.getNotes();
			note.setNoteId(noteList.size()+1);
			noteList.add(note);
			noteUser.setNotes(noteList);
		}
		
		NoteUser savedNoteUser = noteRepo.save(noteUser);
		
		if(savedNoteUser == null) {
			return false;
		}
		return true;
	}
	
	/* This method should be used to delete an existing note. */

	
	public boolean deleteNote(String userId, int noteId) {
		
		if (!noteRepo.findById(userId).isPresent()) {
			return false;
		} else {
			NoteUser noteUser = noteRepo.findById(userId).get();
			List<Note> notes = noteUser.getNotes();
			Iterator<Note> itr = notes.iterator();
			while(itr.hasNext()) {
				if(noteId == itr.next().getNoteId()) {
					itr.remove();
					noteRepo.save(noteUser);
					return true;
				}
			}
			return false;
		}
	}
	
	/* This method should be used to delete all notes with specific userId. */

	
	public boolean deleteAllNotes(String userId) {
		
		if (!noteRepo.findById(userId).isPresent()) {
			return false;
		} else {
			noteRepo.deleteById(userId);
			return true;
		}
	}

	/*
	 * This method should be used to update a existing note.
	 */
	public Note updateNote(Note note, int id, String userId) throws NoteNotFoundExeption {
		
		try {
			if (!noteRepo.findById(userId).isPresent()) {
				throw new NoteNotFoundExeption("404");
			} 
			NoteUser userNote = noteRepo.findById(userId).get();
			List<Note> notes = userNote.getNotes();
			Iterator<Note> itr = notes.iterator();
			int index = 0;
			int counter = 0;
			while(itr.hasNext()) {
				Note noteObj = (Note)itr.next();
				if(noteObj.getNoteId() == id)
				{
					index = notes.indexOf(noteObj);
					counter++;
					/*existingNote.setCategory(note.getCategory());6
					existingNote.setNoteContent(note.getNoteContent());
					existingNote.setNoteCreatedBy(userId);
					existingNote.setNoteStatus(note.getNoteStatus());
					existingNote.setNoteTitle(note.getNoteTitle());
					existingNote.setReminders(note.getReminders());*/
					break;
				}
			}
			if(counter == 0) {
				throw new NoteNotFoundExeption("404");
			}
			notes.remove(index);
			note.setNoteId(id);
			System.out.println("category to save>>>>>>>"+note.getCategory().getCategoryName());
			notes.add(note);
			userNote.setNotes(notes);

			
			for(Note n : notes) {
				System.out.println("Update note:" + n);
			}
			noteRepo.save(userNote);
			return note;
			} catch(Exception e) {
				throw new NoteNotFoundExeption("404");
			}
	}

	/*
	 * This method should be used to get a note by noteId created by specific user
	 */
	public Note getNoteByNoteId(String userId, int noteId) throws NoteNotFoundExeption {
		
		try {
			if (!noteRepo.findById(userId).isPresent()) {
				throw new NoteNotFoundExeption("404");
			} 
			NoteUser noteUser = noteRepo.findById(userId).get();
			List<Note> notes = noteUser.getNotes();
			for(Note existingNote: notes) {
				if(existingNote.getNoteId() == noteId)
				{
					return existingNote;
				} 
			}
			throw new NoteNotFoundExeption("404");
		} catch(Exception e) {
			throw new NoteNotFoundExeption("404");
		}
	}

	/*
	 * This method should be used to get all notes with specific userId.
	 */
	public List<Note> getAllNoteByUserId(String userId) {
		
		List<Note> notes = new ArrayList<>();
			if(noteRepo.findById(userId).isPresent()) {
				NoteUser noteUser = noteRepo.findById(userId).get();
				notes = noteUser.getNotes();
				System.out.println("notes for user:::"+notes);
			} 
		return notes;
	}

}
